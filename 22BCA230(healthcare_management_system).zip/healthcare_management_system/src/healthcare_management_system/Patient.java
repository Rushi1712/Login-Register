package healthcare_management_system;

public class Patient {
    private String name;
    private String contactNo;
    private String address;

    public Patient(String name, String contactNo, String address) {
        this.name = name;
        this.contactNo = contactNo;
        this.address = address;
    }

    // Getters
    public String getName() {
        return name; 
    }
    public String getContactNo() {
        return contactNo; 
    }
    public String getAddress() { 
        return address;
    }

    @Override
    public String toString() {
        return "Patient Name: " + name + ", Contact No: " + contactNo + ", Address: " + address;
    }
}
