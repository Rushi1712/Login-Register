package healthcare_management_system;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Scanner;

public class Healthcare_management_system {
    private List<Patient> patients = new ArrayList<>();
    private List<Doctor> doctors = new ArrayList<>();
    private List<Appointment> appointments = new ArrayList<>();

    public void addPatient(String name, String contactNo, String address) {
        patients.add(new Patient(name, contactNo, address));
        System.out.println("Patient added successfully!");
    }

    public void addDoctor(String name, String specialty) {
        doctors.add(new Doctor(name, specialty));
        System.out.println("Doctor added successfully!");
    }

    public void scheduleAppointment(Patient patient, Doctor doctor, Date date) {
        appointments.add(new Appointment(patient, doctor, date));
        System.out.println("Appointment scheduled successfully!");
    }

    public void viewPatients() {
        System.out.println("Patients List:");
        for (Patient patient : patients) {
            System.out.println(patient);
        }
    }

    public void viewDoctors() {
        System.out.println("Doctors List:");
        for (Doctor doctor : doctors) {
            System.out.println(doctor);
        }
    }

    public void viewAppointments() {
        System.out.println("Appointments List:");
        for (Appointment appointment : appointments) {
            System.out.println(appointment);
        }
    }

    public static void main(String[] args) {
        Healthcare_management_system system = new Healthcare_management_system(); 
        Scanner scanner = new Scanner(System.in);
        
        while (true) {
            System.out.println("\nHealthcare Management System");
            System.out.println("1. Add Patient");
            System.out.println("2. Add Doctor");
            System.out.println("3. Schedule Appointment");
            System.out.println("4. View Patients");
            System.out.println("5. View Doctors");
            System.out.println("6. View Appointments");
            System.out.println("7. Exit");
            System.out.print("Choose an option: ");
            
            int choice = scanner.nextInt();
            scanner.nextLine();  

            switch (choice) {
                case 1:
                    System.out.print("Enter Patient Name: ");
                    String patientName = scanner.nextLine();
                    System.out.print("Enter Contact No: ");
                    String contactNo = scanner.nextLine();
                    System.out.print("Enter Address: ");
                    String address = scanner.nextLine();
                    system.addPatient(patientName, contactNo, address);
                    break;

                case 2:
                    System.out.print("Enter Doctor Name: ");
                    String doctorName = scanner.nextLine();
                    System.out.print("Enter Specialty: ");
                    String specialty = scanner.nextLine();
                    system.addDoctor(doctorName, specialty);
                    break;

                case 3:
                    // Schedule Appointment Logic
                    system.viewPatients();
                    system.viewDoctors();

                    if (!system.patients.isEmpty() && !system.doctors.isEmpty()) {
                        // Allow user to select patient and doctor
                        System.out.print("Select Patient Index (0 to " + (system.patients.size() - 1) + "): ");
                        int patientIndex = scanner.nextInt();
                        scanner.nextLine(); // Consume newline

                        System.out.print("Select Doctor Index (0 to " + (system.doctors.size() - 1) + "): ");
                        int doctorIndex = scanner.nextInt();
                        scanner.nextLine(); // Consume newline

                        if (patientIndex >= 0 && patientIndex < system.patients.size() && 
                            doctorIndex >= 0 && doctorIndex < system.doctors.size()) {
                            Patient selectedPatient = system.patients.get(patientIndex);
                            Doctor selectedDoctor = system.doctors.get(doctorIndex);
                            Date appointmentDate = new Date(); 

                            system.scheduleAppointment(selectedPatient, selectedDoctor, appointmentDate);
                        } else {
                            System.out.println("Invalid selection! Please try again.");
                        }
                    } else {
                        System.out.println("Please add patients and doctors first.");
                    }
                    break;

                case 4:
                    system.viewPatients();
                    break;

                case 5:
                    system.viewDoctors();
                    break;

                case 6:
                    system.viewAppointments();
                    break;

                case 7:
                    scanner.close();
                    return;

                default:
                    System.out.println("Invalid option! Please try again.");
            }
        }
    }
}