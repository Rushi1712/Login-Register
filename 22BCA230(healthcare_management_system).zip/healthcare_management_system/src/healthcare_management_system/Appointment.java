package healthcare_management_system;

import java.util.Date;

public class Appointment {
    private Patient patient;
    private Doctor doctor;
    private Date appointmentDate;

    public Appointment(Patient patient, Doctor doctor, Date appointmentDate) {
        this.patient = patient;
        this.doctor = doctor;
        this.appointmentDate = appointmentDate;
    }

    @Override
    public String toString() {
        return "Appointment [Patient: " + patient.getName() + ", Doctor: " + doctor.getName() +
                ", Date: " + appointmentDate + "]";
    }
}
