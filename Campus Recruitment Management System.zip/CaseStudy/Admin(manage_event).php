<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CRMS - Manage Events</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }

        .container {
            width: 60%;
            margin: 20px auto;
            align:center;
        }

        form {
            background-color: #fff;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        label {
            display: block;
            margin-bottom: 8px;
        }

        input, select {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            box-sizing: border-box;
        }

        button {
            background-color: #004D40;
            color: #fff;
            padding: 10px 15px;
            border: none;
            border-radius: 3px;
            cursor: pointer;
        }
        
        nav {
            background-color: #ddd;
            padding: 10px;
        }

        nav a {
            text-decoration: none;
            color: #333;
            margin-right: 15px;
        }

        table {

            width: 70%;
            border-collapse: collapse;
            margin-top: 20px;
            margin-left:150px;
        }

        th, td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }

        th {
            background-color: #004D40;
            color: #fff;
        }

        tr:nth-child(even) {
            background-color: #f2f2f2;
        }
        .sidebar {
            background-color: #004D40;
            color: white;
            height: 100vh;
            width: 13%;
            position: fixed;
            top: 0;
            left: 0;
            padding: 20px;
    }
    .sidebar ul {
        list-style-type: none;
        padding: 0;
        margin: 0;
    }
    .sidebar ul li a {
            color: white;
            text-decoration: none;
    }
    </style>
</head>
<body>
    
    <div class="sidebar">
    <h2>Manage Events</h2>
    <ul>
        <li><a href="Admin(dashboard).php">Dashboard Home</a></li>
        <li><a href="Admin(manage_users).php">Manage Users</a></li>
        <li><a href="Admin(manage_event).php">Manage Events</a></li>
        <li><a href="Admin(Add_company).php">Add company</a></li>
        <li><a href="Admin(reports).php">Reports</a></li>
        <li><a href="login.php">Logout</a></li>
    </ul>
</div>
    <div class="container">
        <center><h1>Add Events</h1></center>
        <center>
            
        </center>
        <form action="Admin(manage_event).php" METHOD="POST">
            <label for="eventName"><b>Event Name:</b></label>
            <input type="text" id="eventName" name="txtename">
            <label for="eventDate"><b>Event Date:</b></label>
            <input type="date" id="eventDate" name="txtedate">
            <label for="eventLocation"><b>Event Location:</b></label>
            <input type="text" id="eventLocation" name="txtelocation">
            <label for="eventDescription"><b>Event Description:</b> </label>
            <textarea id="eventDescription" name="txtedescription" cols="120" rows="3"></textarea><br><br>
            <button type="submit" name="txtebtn"><b>Add Event</b></button>
        </form>
    </div>
    <?php
$pdo = new PDO("mysql:host=localhost;dbname=case_study","root","");
if(isset($_POST['txtebtn'])) {
    $nm=$_POST['txtename'];
    $date=$_POST['txtedate'];
    $loc=$_POST['txtelocation'];
    $dec=$_POST['txtedescription'];
    $stmt= $pdo ->prepare("insert into manage_event(eventname,date,location,description) values(:eventname,:date,:location,:description)");
    $stmt -> bindparam(':eventname',$nm);
    $stmt -> bindparam(':date',$date);
    $stmt -> bindparam(':location',$loc);
    $stmt -> bindparam(':description',$dec);
    $stmt -> execute();
    header('location:Admin(manage_event).php');
    exit(); // Make sure to exit after redirection
}
?>
<center>
<table>
        <thead>
            <tr>
                <th>Sr.NO</th>
                <th>Event name</th>
                <th>Event date</th>
                <th>Event location</th>
                <th>Event Description</th>
                <th colspan=2>Opration</th>
            </tr>
        </thead>
        <?php
        $pdo = new PDO("mysql:host=localhost;dbname=case_study","root","");
        $stmt=$pdo->query("select * from manage_event");
        $users=$stmt->fetchAll(PDO::FETCH_ASSOC);
        foreach ($users as $user):
        ?>
        <tr>
            <td><?php echo $user['id'];?></td>
            <td><?php echo $user['eventname'];?></td>
            <td><?php echo $user['date'];?></td>
            <td><?php echo $user['location'];?></td>
            <td><?php echo $user['description'];?></td>
            <td><a href="event(update).php?update_id=<?php echo $user['id'];?>">Edit</a></td>
            <td><a href="event(delete).php?delete_id=<?php echo 
            $user['id'];?>">delete</a></td>
        </tr>
        <?php endforeach; ?>
    </table>
</center>
   
</body>
</html>




