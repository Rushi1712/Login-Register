<?php
if(isset($_POST['albtn']))
{
   $name=$_POST['altxtname'];
    $password=$_POST['altxtpass'];
     if($name=="Administrator" && $password=="Admin")
     {
        header('location:Admin(dashboard).php');
     }
    else
     {
         echo "Error";
        echo "<script>alert('Enter The Valid Username And Password..!')</script>";
        //header('location:Admin(login).php');
     }
}
?>