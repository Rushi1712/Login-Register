<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - CRMS</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        .sidebar {
            background-color: #004D40;
            color: white;
            height: 100vh;
            width: 210px;
            position: fixed;
            top: 0;
            left: 0;
            padding: 20px;
        }
        .main-content {
            margin-left: 250px; /* Same as sidebar width */
            padding: 20px;
        }
        h1, h2 {
            color: #00796B;
        }
        ul {
            list-style-type: none;
            padding: 0;
        }
        ul li a {
            color: white;
            text-decoration: none;
        }
        .dashboard-section {
            margin-bottom: 20px;
        }
        footer {
            background-color: #004D40;
            color: white;
            text-align: center;
            width: 100%;
            height:50px;
            font-size:20px;
            padding:10px;
        }

        
    </style>
</head>
<body>

<div class="sidebar">
    <h2>Admin Dashboard</h2>
    <ul>
        <li><a href="Admin(dashboard).php">Dashboard Home</a></li>
        <li><a href="Admin(manage_users).php">Manage Users</a></li>
        <li><a href="Admin(manage_event).php">Manage Events</a></li>
        <li><a href="Admin(Add_company).php">Add company</a></li>
        <li><a href="Admin(reports).php">Reports</a></li>
        <li><a href="login.php">Logout</a></li>
    </ul>
</div>

<div class="main-content">
    <h1>Welcome, Admin!</h1>
    
    <div class="dashboard-section">
        <h2>Quick Overview</h2>
        <p><b>Here you can see a snapshot of the system's current state.</b></p>
        <!-- Example of some quick stats -->
        <ul>
            <li><b>Number of Students:</b> 1200</li>
            <li><b>Number of Companies:</b> 85</li>
            <li><b>Upcoming Events:</b> 5</li>
        </ul>
    </div>
    
    <div class="dashboard-section">
        <h2>Recent Activity</h2>
        <p>Overview of recent system activity.</p>
        <!-- Placeholder for activity log or summary -->
    </div>
    
    <!-- Additional sections can be added here -->
</div>

</body>
</html>
