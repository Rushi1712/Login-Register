<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Page - CRMS</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }

        header {
            background-color: #004D40;
            color: #fff;
            text-align: center;
            padding: 10px;
        }

        section {
            max-width: 800px;
            margin: 20px auto;
            background-color: #fff;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        img {
            max-width: 100%;
            border-radius: 50%;
        }

        .student-info {
            display: flex;
            align-items: center;
            margin-bottom: 20px;
        }

        .student-details {
            margin-left: 20px;
        }

        h2 {
            color: #333;
        }

        .applications {
            margin-top: 20px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 10px;
        }

        th, td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }

        th {
            background-color: #004D40;
            color: #fff;
        }
        a,input{
            background-color: #004D40;
            color: #fff;
            font-size:20px;
            border-radius:20px;
            margin-bottom:20px;
        }
    </style>
</head>

<body>

    <header>
        <h1>STUDENT PROFILE</h1>
    </header>

    <section>
        <div class="student-info">
            <img src="profile-picture.jpg" alt="Student Profile Picture" width="100">
            <div class="student-details">
            <a href="home.php"><input type="submit" name="back" value="Logout"></a>
                <h2>John Doe</h2>
                <p>Batch: 2024</p>
                <p>Department: Computer Science</p>
            </div>
        </div>

        <div class="applications">
            <h2>Job Applications</h2>
            <table>
                <thead>
                    <tr>
                        <th>Company</th>
                        <th>Position</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>ABC Corp</td>
                        <td>Software Engineer</td>
                        <td>Applied</td>
                    </tr>
                    <tr>
                        <td>XYZ Ltd</td>
                        <td>Data Analyst</td>
                        <td>Under Review</td>
                    </tr>
                    <!-- Add more rows as needed -->
                </tbody>
            </table>
        </div>
    </section>

</body>

</html>
