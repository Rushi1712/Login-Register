<?php
if(isset($_GET['update_id'])) {
    $pdo = new PDO("mysql:host=localhost;dbname=case_study","root","");
    $id = $_GET['update_id'];
    $stmt = $pdo->prepare("SELECT * FROM manage_event WHERE id = :id");
    $stmt->bindParam(':id', $id);
    $stmt->execute();
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CRMS - Update Event</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }

        header {
            background-color: #004D40;
            color: #fff;
            padding: 5px;
            text-align: center;
        }

        form {
            background-color: #fff;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            width: 60%;
            margin: 20px auto;
        }

        table {
            width: 100%;
        }

        th, td {
            padding: 10px;
            text-align: left;
        }

        label {
            display: block;
            margin-bottom: 8px;
        }

        input, textarea {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            box-sizing: border-box;
        }

        button {
            background-color: #004D40;
            color: #fff;
            padding: 10px 15px;
            border: none;
            border-radius: 3px;
            cursor: pointer;
            display: block;
            margin: 0 auto;
        }
    </style>
</head>
<body>
    <header>
        <h1>CRMS - Update Event</h1>
    </header>
    <form action="" method="POST">
        <table>
            <tr>
                <th><label for="eventName"><b>Event Name:</b></label></th>
                <td><input type="text" value="<?php echo isset($user['eventname']) ? $user['eventname'] : ''; ?>" name="txtename"></td>
            </tr>
            <tr>
                <th><label for="eventDate"><b>Event Date:</b></label></th>
                <td><input type="date" value="<?php echo isset($user['date']) ? $user['date'] : ''; ?>" name="txtedate"></td>
            </tr>
            <tr>
                <th><label for="eventLocation"><b>Event Location:</b></label></th>
                <td><input type="text" value="<?php echo isset($user['location']) ? $user['location'] : ''; ?>" name="txtelocation"></td>
            </tr>
            <tr>
                <th><label for="eventDescription"><b>Event Description:</b></label></th>
                <td><textarea id="eventDescription" name="txtedescription" cols="117" rows="3"><?php echo isset($user['description']) ? $user['description'] : ''; ?></textarea></td>
            </tr>
            <tr>
                <td colspan="2"><button type="submit" name="txtbtn"><b>Update Event</b></button></td>
            </tr>
        </table>
    </form>
</body>
</html>

<?php
if(isset($_POST['txtbtn'])) { 
    $pdo = new PDO("mysql:host=localhost;dbname=case_study","root",""); 
    $id = isset($_GET['update_id']) ? $_GET['update_id'] : null;
    $name = $_POST['txtename']; 
    $date = $_POST['txtedate'];
    $loc = $_POST['txtelocation']; 
    $des = $_POST['txtedescription']; 
    
    if($id) {
        $sql = "UPDATE manage_event SET eventname=:eventname, date=:date, location=:location, description=:description WHERE id=:id";
        $stmt = $pdo->prepare($sql); 
        $stmt->bindParam(':eventname', $name); 
        $stmt->bindParam(':date', $date); 
        $stmt->bindParam(':location', $loc); 
        $stmt->bindParam(':description', $des); 
        $stmt->bindParam(':id', $id); 
        $stmt->execute(); 
        header('location:Admin(manage_event).php'); 
    } else {
        echo "Update ID not set.";
    }
} 
?>
