<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <style>
    body {
      font-family: Arial, sans-serif;
      margin: 0;
      padding: 0;
      background-color: #f4f4f4;
    }
    section {
      padding: 20px;
      width:100%;
    }
    form {
      max-width: 400px;
      margin: 20px auto;
    }

    label {
      display: block;
      margin-bottom: 8px;
    }

    input {
      width: 100%;
      padding: 8px;
      margin-bottom: 15px;
      box-sizing: border-box;
    }

    button {
      background-color: #004D40;
      color: #fff;
      padding: 10px 15px;
      border: none;
      cursor: pointer;
    }

    button:hover {
      background-color: #004D40;
    }
    #role{
        width:300px;
        font-size:20px;
    }
    label{
        font-size:20px;
    }
    .sidebar {
            background-color: #004D40;
            color: white;
            height: 100vh;
            width: 210px;
            position: fixed;
            top: 0;
            left: 0;
            padding: 20px;
    }
    .sidebar ul {
        list-style-type: none;
        padding: 0;
        margin: 0;
    }
    .sidebar ul li a {
            color: white;
            text-decoration: none;
    }

    /* CSS for table */
    table {
      width:100%;
      border-collapse: collapse;
      margin-top: 50px;
    }

    th, td {
      border: 1px solid #ddd;
      padding: 8px;
      text-align: left;
    }

    th {
      background-color: #004D40;
      color: white;
    }

    tr:nth-child(even) {
      background-color: #f2f2f2;
    }
  </style>
  <title>Manage Users - CRM System</title>
</head>
<body>

  <div class="sidebar">
    <h2>Manage Users</h2>
    <ul>
        <li><a href="Admin(dashboard).php">Dashboard Home</a></li>
        <li><a href="Admin(manage_users).php">Manage Users</a></li>
        <li><a href="Admin(manage_event).php">Manage Events</a></li>
        <li><a href="Admin(Add_company).php">Add company</a></li>
        <li><a href="Admin(reports).php">Reports</a></li>
        <li><a href="login.php">Logout</a></li>
    </ul>
</div>
<?php
$pdo = new PDO("mysql:host=localhost;dbname=case_study","root","");
if(isset($_POST['btn']))
{
    $nm=$_POST['txtname'];
    $uname=$_POST['txtuname'];
    $pass=$_POST['txtpass'];
    $role=$_POST['txturole'];
    $stmt= $pdo->prepare("INSERT INTO manage_user (name, username, password, role) VALUES (:name, :username, :password, :role)");
    $stmt->bindParam(':name', $nm);
    $stmt->bindParam(':username', $uname);
    $stmt->bindParam(':password', $pass);
    $stmt->bindParam(':role', $role);
    $stmt->execute();
    header('location:Admin(manage_users).php');
}
?>

  <section>
   <Center><h2>MANAGE USERS</h2></Center> 

    <form action="Admin(manage_users).php" METHOD="POST">
    <label>Name:</label>
      <input type="text" id="username" name="txtname" required>
      <label>Username:</label>
      <input type="text" id="username" name="txtuname" required>
      <label>Password:</label>
      <input type="password" id="username" name="txtpass" required>
      <label>Role:</label>
      <select id="role" name="txturole" required>
      <option>select</option>
        <option value="Admin">Admin</option>
        <option value="Coordinator">Coordinator</option>
        <option value="Student">Student</option>
        <!-- Add more roles as needed -->
      </select><br><br>

      <button type="submit" name="btn">Add User</button>
    </form>

    <form action="" METHOD="POST" class="form">
      <table>
        <thead>
          <tr>
            <th>Sr.NO</th>
            <th>Username</th>
            <th>Role</th>
          </tr>
        </thead>

        <?php
        $pdo = new PDO("mysql:host=localhost;dbname=case_study","root","");
        $stmt=$pdo->query("select * from manage_user");
        $users=$stmt->fetchAll(PDO::FETCH_ASSOC);
        foreach ($users as $user):
        ?>
        <tr>
          <td><?php echo $user['id'];?></td>
          <td><?php echo $user['username'];?></td>
          <td><?php echo $user['role'];?></td>
        </tr>
        <?php
        endforeach;
        ?>
      </table>
    </form>
  </section>
</body>
</html>
