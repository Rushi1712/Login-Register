<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Campus Recruitment Management System</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            
        }
        .header {
            background-color: #004D40;
            color: white;
            padding: 10px;
            text-align: center;
            display: flex;
            justify-content:space-between; /* Align items horizontally with space in-between */
            align-items: center; /* Align items vertically */
        }
        .button {
            
            border-radius:30px;
            color:white;
            font-size:30px; /* Adjusted font size */
            background-color:#004D40;
            padding: 10px 20px; /* Added padding for better appearance */
            margin-right: 100px; /* Added margin to separate from the right edge */
            text-decoration: none; 
        }
         
        .main-content {
            padding: 20px;
        }
        .features, .login, .contact {
            margin-bottom: 5px;
        }
        .features h2, .login h2, .contact h2 {
            color: #00796B;
        }
        footer {
            background-color: #004D40;
            color: white;
            text-align: center;
            width: 100%;
            height:50px;
            font-size:20px;
            padding:10px;
        }
h4{
    color:red;
}

/* You can keep the rest of your CSS for hover effects and dropdown menus as is */

    </style>
</head>
<body>

<div class="header">
    <h1>Campus Recruitment Management System</h1>
    <a href="login.php"  class=button><b>Login</b></a>
    
</div>

<div class="main-content">
    <div class="features">
        <h2>Features</h2>
        <p><b>Our Campus Recruitment Management System offers the following features:</b></p>
        <ul>
            <li>Comprehensive dashboard for admin, coordinators, and students.</li>
            <li>Real-time notification of campus recruitment events.</li>
            <li>Automated resume submission and management.</li>
            <li>Interview scheduling and feedback system.</li>
        </ul>
    </div>
    <div class="contact">
        <h2>About Us</h2>
       <h4>Our mission</h4>
         <p>At our Company, we are dedicated to transforming the campus recruitment process. Our Campus Recruitment Management System (CRMS) is designed to bridge the gap between talented students and leading employers, ensuring a seamless, efficient, and equitable recruitment process. Our mission is to empower students with the opportunities they deserve and provide recruiters with the tools they need to find the talent they seek.</p>
         <h4>What We Do</h4>
        <p>Our CRMS offers an end-to-end recruitment solution that streamlines the entire campus hiring process. From job postings and application tracking to scheduling interviews and managing offers, our system is equipped with a range of features to facilitate every step of the recruitment journey. We provide:</p>

        <p><b>For Students:</b>A platform to discover opportunities, apply easily, track application statuses, and access resources to prepare for interviews.</p>

       <b>For Recruiters:</b>A comprehensive dashboard to post job openings, manage applications, schedule interviews, and communicate directly with candidates.</p>

        <p><b>For Colleges:</b>Tools to monitor and support the recruitment process, ensuring their students are well-represented and have access to a wide range of opportunities.</p>

        <h4>Our Vision</h4>
        <p>We envision a world where every student has the chance to pursue their dream job, regardless of their background or where they study. We believe in democratizing campus recruitment, making it more accessible, transparent, and efficient for all parties involved. Through our CRMS, we aim to unlock new possibilities for students, recruiters, and educational institutions worldwide.</p>
</div>
    <div class="contact">
        <h2>Contact Us</h2>
        <p>If you have any questions, please feel free to reach out to our support team.</p>
       <b><p>Email: support@crms.com</p>
        <p>Phone: +123 456 7890</p></b>
    </div>
</div>

<footer>
    <p>&copy; 2024 Campus Recruitment Management System. All rights reserved.</p>
</footer>

</body>
</html>
