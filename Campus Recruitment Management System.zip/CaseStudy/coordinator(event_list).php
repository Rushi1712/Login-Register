<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        table {
      width: 100%;
      border-collapse: collapse;
      margin-top: 10px;
    }

    th, td {
      padding: 12px;
      text-align: left;
      font-size:20px;
      border-bottom: 1px solid #ddd;
    }

    th {
      background-color: #004D40;
      color: #fff;
    }
    button {
      background-color: #004D40;
      color: #fff;
      padding: 10px 15px;
      border: none;
      cursor: pointer;
    }
    header {
            background-color: #004D40;
            color: #fff;
            padding: 10px;
            text-align: center;
        }

    button:hover {
      background-color: #004D40;
    }
    input{
      background-color:#004D40;
      color: #fff;
      border:5px solid white;
      font-size:20px;
      border-radius:30px;
    }
    </style>
</head>
<body>
<header>
        <h1>CRMS -Event List</h1>
    </header>
<table>
      <thead>
        <tr>
          <th>Event name</th>
          <th>Event date</th>
          <th>Event location</th>
          <th>Event Description</th>
          <th><a href="coordinator(dashboard).php"><input type="submit" name="back" value="Back"></a></th>

        </tr>
      </thead>
      <tbody>
        <!-- Display user data dynamically here -->
        <tr>
          <td>Expert session</td>
          <td>12-apr-2024</td>
          <td>rpcp-institute</td>
          <td colspan=2>it is for pg student. this session about current programming languaged.</td>
        </tr>
        <!-- Add more rows as needed -->
      </tbody>
    </table>
</body>
</html>

