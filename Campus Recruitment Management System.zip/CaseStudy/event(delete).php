<?php
if(isset($_GET['delete_id'])) { 
    $pdo = new PDO("mysql:host=localhost;dbname=case_study","root",""); 
    $idToDelete = $_GET['delete_id']; 
    $stmt = $pdo->prepare("DELETE FROM manage_event WHERE id = :id"); 
    $stmt->bindParam(':id',$idToDelete); 
    $stmt->execute(); 
    header("location:Admin(manage_event).php");
    exit(); 
} 
?>
