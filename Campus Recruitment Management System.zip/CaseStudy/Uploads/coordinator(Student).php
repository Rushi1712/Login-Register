<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        table {
      width: 100%;
      border-collapse: collapse;
      margin-top: 20px;
    }

    th, td {
      padding: 12px;
      text-align: left;
      border-bottom: 1px solid #ddd;
    }

    th {
      background-color: #004D40;
      color: #fff;
    }
    button {
      background-color: #004D40;
      color: #fff;
      padding: 10px 15px;
      border: none;
      cursor: pointer;
    }

    button:hover {
      background-color: #004D40;
    }
    input{
      background-color:#004D40;
      color: #fff;
      border:5px solid white; 
      font-size:20px;
      border-radius:30px;
      
    }
    </style>
</head>
<body>
<table>
      <thead>
        <tr>
          <th>Student Name</th>
          <th>E-mail</th>
          <th>Phone number</th>
          <th>Univercity</th>
          <th>Degree</th>
          <th>CGPA</th>
          <th>Graduation Year</th>
          <th>Position Applied for</th>
          <th>Resume</th>
          <th>Opration</th>
          <th><a href="coordinator(dashboard).php"><input type="submit" name="back" value="Back"> </a></th>
        </tr>
      </thead>
      <tbody>
        <!-- Display user data dynamically here -->
        <tr>
          <td>john_doe</td>
          <td>abc@gmail.com</td>
          <td>000-0000-000</td>
          <td>Charusat</td>
          <td>BCA</td>
          <td>9.33</td>
          <td>2025</td>
          <td>devloper</td>
           <td><button>Download</button></td> 
          <td colspan=2><button>Edit</button> <button>Delete</button></td>
        </tr>
        
      </tbody>
    </table>
</body>
</html>

