<?php
$pdo = new PDO("mysql:host=localhost;dbname=case_study","root","");
if(isset($_POST['txtebtn'])) {
    $nm=$_POST['txtename'];
    $date=$_POST['txtedate'];
    $loc=$_POST['txtelocation'];
    $dec=$_POST['txtedescription'];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        table {
      width: 100%;
      border-collapse: collapse;
      margin-top: 10px;
      
      
    }

    th, td {
      padding: 12px;
      font-size:20px;
      text-align: left;
      font-size:20px;
    }

    th {
      background-color: #004D40;
      color: #fff;
    }
    button {
      background-color: #004D40;
      color: #fff;
      padding: 10px 15px;
      border: none;
      cursor: pointer;
    }
    header {
            background-color: #004D40;
            color: #fff;
            padding: 10px;
            font-size:20px;
            text-align: center;
        }

    button:hover {
      background-color: #004D40;
    }
    input{
      background-color:#004D40;
      color: #fff;
      border:5px solid white;
      font-size:20px;
      border-radius:30px;
    }
    </style>
</head>
<body>
<header>
        <h1>CRMS -Event List</h1>
    </header>
    <center>
        <?php
$pdo = new PDO("mysql:host=localhost;dbname=case_study","root","");
if(isset($_POST['txtebtn'])) {
    $nm=$_POST['txtename'];
    $date=$_POST['txtedate'];
    $loc=$_POST['txtelocation'];
    $dec=$_POST['txtedescription'];
    $stmt= $pdo ->prepare("insert into manage_event(eventname,date,location,description) values(:eventname,:date,:location,:description)");
    $stmt -> bindparam(':eventname',$nm);
    $stmt -> bindparam(':date',$date);
    $stmt -> bindparam(':location',$loc);
    $stmt -> bindparam(':description',$dec);
    $stmt -> execute();
    header('location:Admin(manage_event).php');
    exit(); // Make sure to exit after redirection
}
?>
<center>
<table>
        <thead>
            <tr>
                <th>Sr.NO</th>
                <th>Event name</th>
                <th>Event date</th>
                <th>Event location</th>
                <th>Event Description</th>
                <th colspan=2>Opration</th>
            </tr>
        </thead>
        <?php
        $pdo = new PDO("mysql:host=localhost;dbname=case_study","root","");
        $stmt=$pdo->query("select * from manage_event");
        $users=$stmt->fetchAll(PDO::FETCH_ASSOC);
        foreach ($users as $user):
        ?>
        <tr>
            <td><?php echo $user['id'];?></td>
            <td><?php echo $user['eventname'];?></td>
            <td><?php echo $user['date'];?></td>
            <td><?php echo $user['location'];?></td>
            <td><?php echo $user['description'];?></td>
            <td><a href="event(update).php?update_id=<?php echo $user['id'];?>">Edit</a></td>
            <td><a href="event(delete).php?delete_id=<?php echo 
            $user['id'];?>">delete</a></td>
        </tr>
        <?php endforeach; ?>
    </table>
</center>
   
</body>
</html>
</center>
</body>
</html>

