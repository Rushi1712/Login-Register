<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Coordinator Dashboard - CRMS</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f0f2f5;
        }
        .dashboard-header {
            background-color: #004D40;
            color: #ffffff;
            padding: 20px;
            text-align: center;
        }
        .dashboard-menu {
            background-color: #004D45;
            color: white;
            padding: 15px;
            margin-top:10px;
        }
        .dashboard-menu a {
            color: #ffffff;
            text-decoration: none;
            padding: 10px;
            display: inline-block;
        }
        .dashboard-content {
            padding: 20px;
        }
        .card {
            background-color: #ffffff;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            margin-bottom: 20px;
            padding: 20px;
        }
        .card-header {
            font-size: 20px;
            margin-bottom: 15px;
        }
    </style>
</head>
<body>

<div class="dashboard-header">
    <h1>Coordinator Dashboard</h1>
</div>

<div class="dashboard-menu">
    <a href="home.php">Home</a>
    <a href="coordinator(event_List).php">Events</a>
    <a href="coordinator(companies).php">Companies</a>
    <a href="coordinator(student).php">Students</a>
    
</div>

<div class="dashboard-content">
    <div class="card">
        <div class="card-header">Upcoming Recruitment Events</div>
        <ul>
            <li>Company ABC - Software Engineer Roles - March 15, 2024</li>
            <li>Company XYZ - Internship Positions - March 20, 2024</li>
        </ul>
    </div>
    
    <div class="card">
        <div class="card-header">Latest Student Applications</div>
        <ul>
            <li>John Doe - Applied to Company ABC</li>
            <li>Jane Smith - Applied to Company XYZ</li>
        </ul>
    </div>
    <div class="card">
        <div class="card-header">Latest Student Applications</div>
        <ul>
            <li>John Doe - Applied to Company ABC</li>
            <li>Jane Smith - Applied to Company XYZ</li>
        </ul>
    </div>
</div>

</body>
</html>
