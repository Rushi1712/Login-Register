<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        table {
      width: 80%;
      border-collapse: collapse;
      margin-top: 20px;
    }

    th, td {
      padding: 12px;
      font-size:20px;
      text-align: left;
      border-bottom: 1px solid #ddd;
    }

    th {
      background-color:#004D40;
      color: #fff;
    }
    button {
      background-color: #004D40;
      color: #fff;
      padding: 10px 15px;
      border: none;
      cursor: pointer;
    }
    input{
      background-color:#004D40;
      color: #fff;
      border:5px solid white;
      font-size:20px;
      border-radius:30px;
    }
    button:hover {
      background-color:#004D40;
    }
    header {
            background-color: #004D40;
            color: #fff;
            padding: 3px;
            text-align: center;
        }
        
    </style>
</head>
<body>
<header>
        <h1>CRMS -Report List</h1>
    </header>
<table class="display">
      <thead>
        <tr>
          <th>Sr.No</th>
          <th>Report name</th>
          <th>Ganreted by</th>
          <th>Ganreted date</th>
          <th>download</th>
          <th><a href="Admin(dashboard).php"><input type="submit" name="back" value="Back"></a></th>
        </tr>
      </thead>
      <?php
      $pdo = new PDO("mysql:host=localhost;dbname=case_study","root","");
      $stmt=$pdo->query("select * from reports");
      $users=$stmt->fetchAll(PDO::FETCH_ASSOC);
      foreach ($users as $user):
?>
        <tr>
        <td><?php echo $user['id'];?></td>
          <td><?php echo $user['rname'];?></td>
          <td><?php echo $user['ganreted_by'];?></td>
          <td><?php echo $user['date'];?></td>
          <td colspan=2><button><a href="<?php echo $user['path'];?>" style=color:white download>Download</a></button></td>
        </tr>
<?php
endforeach;
?>
    </table>
</body>
</html>

