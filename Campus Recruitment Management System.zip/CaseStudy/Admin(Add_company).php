<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CRMS - Add company</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }

        .sidebar {
            background-color: #004D40;
            color: white;
            height: 100vh;
            width: 13%;
            position: fixed;
            top: 0;
            left: 0;
            padding: 20px;
    }
    .sidebar ul {
        list-style-type: none;
        padding: 0;
        margin: 0;
    }
    .sidebar ul li a {
            color: white;
            text-decoration: none;
    }

        .container {
            width: 50%;
            margin-left:33%;
            margin-top:70px;
        }

        form {
            background-color: #fff;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        label {
            display: block;
            margin-bottom: 8px;

        }

        input, select {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            box-sizing: border-box;
        }

        button {
            background-color: #004D40;
            color: #fff;
            padding: 10px 15px;
            border: none;
            border-radius: 3px;
            cursor: pointer;
        }
        nav {
      background-color: #ddd;
      padding: 10px;
    }

    nav a {
      text-decoration: none;
      color: #333;
      margin-right: 15px;
    }
    </style>
</head>
<body>

    
    <div class="sidebar">
    <h2>Add Company</h2>
    <ul>
        <li><a href="Admin(dashboard).php">Dashboard Home</a></li>
        <li><a href="Admin(manage_users).php">Manage Users</a></li>
        <li><a href="Admin(manage_event).php">Manage Events</a></li>
        <li><a href="Admin(Add_company).php">Add company</a></li>
        <li><a href="Admin(reports).php">Reports</a></li>
        <li><a href="login.php">Logout</a></li>
    </ul>
</div>
<?php
$pdo = new PDO("mysql:host=localhost;dbname=case_study","root","");
if(isset($_POST['btn']))
{
    $cnm=$_POST['txtname'];
    $coorname=$_POST['txtcoorname'];
    $phno=$_POST['ph_no'];
    $mail=$_POST['mail'];
    $web=$_POST['txtweb'];
    $stmt= $pdo->prepare("INSERT INTO add_company (cname,coorname, ph_no, email, web) VALUES (:cname,:coorname,:ph_no,:email,:web)");
    $stmt->bindParam(':cname', $cnm);
    $stmt->bindParam(':coorname', $coorname);
    $stmt->bindParam(':ph_no', $phno);
    $stmt->bindParam(':email', $mail);
    $stmt->bindParam(':web', $web);
    $stmt->execute();
    header('location:Admin(Add_company).php');
}
?>

    <div class="container">
    <center><h2>Add Company</h2></center>
        <form action="Admin(add_company).php" method="POST">
            <label for="companyName"><b>Company Name:</b></label>
            <input type="text" id="companeyName" name="txtname" required>

            <label for="companycoorname"><b>company's coordinator Name:</b></label>
            <input type="text" id="companycoorname" name="txtcoorname" required>

            <label for="ph.no"><b>Contact No:</b></label>
            <input type="number" id="ph.no" name="ph_no" required>

            <label for="mail"><b>company's Email-Id:</b></label>
            <input type="email" id="mail" name="mail" required>

            <label for="eventLocation"><b>Website:</b></label>
            <input type="text" id="companyweb" name="txtweb" required>


            <button type="submit" name="btn"><b>Add Company</b></button>
        </form>
    </div>
    </select><br><br>

      <button type="submit" name="btn">Add User</button>
    </form>

    <form action="" METHOD="POST" class="form">
      <table>
        <thead>
          <tr>
            <td>Sr.No</td>
            <th>company Name</th>
            <th>company's coordinator Name</th>
            <th>Contact No</th>
            <th>company's Email-Id</th>
            <th>Website</th>
          </tr>
        </thead>

        <?php
        $pdo = new PDO("mysql:host=localhost;dbname=case_study","root","");
        $stmt=$pdo->query("select * from Add_company");
        $users=$stmt->fetchAll(PDO::FETCH_ASSOC);
        foreach ($users as $user):
        ?>
        <tr>
          <td><?php echo $user['id'];?></td>
          <td><?php echo $user['cname'];?></td>
          <td><?php echo $user['coorname'];?></td>
          <td><?php echo $user['ph_no'];?></td>
          <td><?php echo $user['web'];?></td>
        </tr>
        <?php
        endforeach;
        ?>
      </table>
    </form>
  </section>
</body>
</html>
