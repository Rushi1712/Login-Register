<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <style>
    body {
      font-family: Arial, sans-serif;
      margin: 0;
      padding: 0;
      background-color: #f4f4f4;
    }

    header {
      background-color: #004D40;
      color: #fff;
      padding: 10px;
      text-align: center;
    }

    nav {
      background-color: #ddd;
      padding: 10px;
    }

    nav a {
      text-decoration: none;
      color: #333;
      margin-right: 15px;
    }

    section {
      padding: 20px;
    }

    table {
      width: 100%;
      border-collapse: collapse;
      margin-top: 20px;
    }

    th, td {
      padding: 12px;
      text-align: left;
      border-bottom: 1px solid #ddd;
    }

    th {
      background-color: #004D40;
      color: #fff;
    }

    form {
      max-width: 400px;
      margin: 20px auto;
    }

    label {
      display: block;
      margin-bottom: 8px;
    }

    input {
      width: 100%;
      padding: 8px;
      margin-bottom: 15px;
      box-sizing: border-box;
    }

    button {
      background-color: #004D40;
      color: #fff;
      padding: 10px 15px;
      border: none;
      cursor: pointer;
    }

    button:hover {
      background-color: #004D40;
    }
    #role{
        width:300px;
        font-size:20px;
    }
    label{
        font-size:20px;
    }
  </style>
  <title>Manage Users - CRM System</title>
</head>
<body>

  <header>
    <h1>CRMS-Add Reports</h1>
  </header>

  <nav>
    <a href="Admin(dashboard).php">Dashboard</a>
    <a href="Admin(reports).php">Add Reports</a>
    <a href="Admin(report_list).php">Reports List</a>
    <!-- Add more navigation links as needed -->
  </nav>

  <section>
   
  <form action="Admin(reports).php" method="POST" enctype="multipart/form-data">
      <label for="username">Report name:</label>
      <input type="text" id="username" name="txtrname" required><br>
      <label for="role">Ganreted By:</label>
      <select id="role" name="txtgenreted" required>
      <option>select</option>
        <option value="Admin">Admin</option>
        <option value="Coordinator">Coordinator</option>
        <option value="Student">Student</option>
      </select><br><br>
      <label for="username">Date Ganreted:</label>
      <input type="date" id="username" name="txtrdate" required><br>
      <label for="upload">Upload report:</label>
      <input type="file" id="uploadreport" name="txtupload"required><br>
      <button type="submit" name="txtrbtn">Add Report</button>
    </form>
  </section>
</body>
</html>

<?php
$pdo = new PDO("mysql:host=localhost;dbname=case_study","root","");
if(isset($_POST['txtrbtn']))
{
    $nm=$_POST['txtrname'];
    $role=$_POST['txtgenreted'];
    $date=$_POST['txtrdate'];

    // File Upload Handling
    $td="uploads/"; //targeted directory
    $tf=$td . basename($_FILES['txtupload']["name"]);
    $up=1;
    $ift = strtolower(pathinfo($tf, PATHINFO_EXTENSION));
   
    if($ift!="pdf" && $ift!="docx") // Corrected condition
    {
        echo "Only PDF and DOCX files are allowed";
        $up=0;
    }
    if($up==0)
    {
        echo "File is not uploaded";
    }
    else{
        if(move_uploaded_file($_FILES["txtupload"]["tmp_name"], $tf))
        {
            echo "File uploaded successfully";
            $iname=$_FILES["txtupload"]["name"];
            $ipath=$tf;
            $stmt=$pdo->prepare("INSERT INTO reports(name, path, rname, ganreted_by, date) 
                                VALUES (:name, :path, :rname, :ganreted_by, :date)");
            $stmt->bindparam(':name', $iname);
            $stmt->bindparam(':path', $ipath);
            $stmt->bindparam(':rname', $nm);
            $stmt->bindparam(':ganreted_by', $role);
            $stmt->bindparam(':date', $date);
            $stmt->execute();
            header('location:Admin(reports).php'); // Corrected redirect URL
            exit(); // Added exit() to prevent further execution
        }
        else{
            echo "Error in file upload";
        }
    }
}
?>
