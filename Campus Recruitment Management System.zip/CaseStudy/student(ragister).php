<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CRMS - student ragister</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }

        header {
            background-color: #350;
            color: #fff;
            padding: 1em;
            text-align: center;
        }

        .container {
            width: 50%;
            margin: 20px auto;
        }

        form {
            background-color: #fff;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        label {
            display: block;
            margin-bottom: 8px;

        }

        input, select {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            box-sizing: border-box;
        }

        button {
            background-color: #350;
            padding: 10px 15px;
            border: none;
            border-radius: 3px;
            cursor: pointer;
        }
        nav {
      background-color: #ddd;
      padding: 10px;
    }

    nav a {
      text-decoration: none;
      color: #333;
      padding:20px;
      
    }
    a {
            text-decoration: none;
            color: coral;
            margin-top: 10px;
            font-size:20px;
        }
    .sign_up{
            padding:30px;
    }
    </style>
</head>
<body>

    <header>
        <h1>CRMS - STUDENT RAGISTRATION</h1>
    </header>
    <div class="container">
    <form action="" method="post">
 
        Full Name:-<input type="text" id="full_name" name="full_name" required><br>
        
        Date of Birth:-<input type="date" id="date" name="date" required><br>
       Select Gender:- <select id="gender" name="gender"><br>
  
         <option value="Male">Male</option>
        <option value="Female">Female</option>
</select>

        <br>
        Email:-<input type="text" id="email" name="email" required><br>

        <label for="phone">Phone Number:</label>
        <input type="tel" id="phone" name="phone" required>

        <label for="university">University:</label>
        <input type="text" id="university" name="university" required>

        <label for="Department">Department:</label>
        <input type="text" id="Department" name="Department" required>

        <label for="degree">Degree:</label>
        <input type="text" id="degree" name="degree" required>
        <label for="degree">CGPA:</label>
        <input type="text" id="CGPA" name="cgpa" required>

        <label for="graduation_year">Graduation Year:</label>
        <input type="text" id="graduation_year" name="graduation_year" required>

        <!-- Job-related Information -->
        <label for="position">Position Applied For:</label>
        <input type="text" id="position" name="position" required>

        <label for="Com">Company Name:</label>
        <input type="text" id="Com" name="Com" required>

        <label for="resume">Upload Resume (PDF or Word):</label>
        <input type="file" id="resume" name="resume" accept=".pdf,.doc,.docx" required>
        <button type="submit" name="sdbtn"><a href="student(details).php" style=color:white>Submit</button>
        <a href="student(login).php" class="sign_up">Login</a>
    </form>
    </div>

</body>
</html>
