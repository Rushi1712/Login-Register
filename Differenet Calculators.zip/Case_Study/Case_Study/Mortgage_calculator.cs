﻿using System;
using System.Windows.Forms;

namespace Case_Study
{
    public partial class Mortgage_calculator : Form
    {
        public Mortgage_calculator()
        {
            InitializeComponent();
        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {
            int Hprice = Convert.ToInt32(txtHomePrice.Text);
            int downpayment = Convert.ToInt32(Hprice * Convert.ToInt32(txtDownPayment.Text) / 100);

            int loanamount = Hprice - downpayment;

            int loanTermYears = Convert.ToInt32(txtLoanTerm.Text);
            double annualInterestRate = Convert.ToDouble(txtInterestRate.Text);

            double monthlyRate = (annualInterestRate / 100) / 12;

            int totalPayments = loanTermYears * 12;

            double monthlyPayment = (loanamount * monthlyRate * Math.Pow(1 + monthlyRate, totalPayments)) / (Math.Pow(1 + monthlyRate, totalPayments) - 1);

            double totalInterest = (monthlyPayment * totalPayments) - loanamount;

            string mortgageStartDate = cmbStartDate.Text + " " + txtStartDate.Text;

            MessageBox.Show("Home Price: $" + Hprice +
                            "\n\nDown Payment: $" + downpayment +
                            "\n\nLoan Amount: $" + loanamount +
                            "\n\nMonthly Payment: $" + Math.Round(monthlyPayment, 2) +
                            "\n\nTotal Interest: $" + Math.Round(totalInterest, 2) +
                            "\n\nMortgage Payoff Date: " + txtStartDate.Text, " ",MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            txtHomePrice.Clear();
            txtDownPayment.Clear();
            txtLoanTerm.Clear();
            txtInterestRate.Clear();
        }
    }
}
