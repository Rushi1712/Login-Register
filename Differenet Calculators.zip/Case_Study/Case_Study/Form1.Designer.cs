﻿namespace Case_Study
{
    partial class main_form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.linkLabelMortgage = new System.Windows.Forms.LinkLabel();
            this.linkLabelIntrest = new System.Windows.Forms.LinkLabel();
            this.linkLabelLoan = new System.Windows.Forms.LinkLabel();
            this.linkLabelIntrestRate = new System.Windows.Forms.LinkLabel();
            this.linkLabelIncomeTax = new System.Windows.Forms.LinkLabel();
            this.linkLabelPayment = new System.Windows.Forms.LinkLabel();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(159, 27);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(198, 25);
            this.label1.TabIndex = 0;
            this.label1.Text = "Financial calculator";
            // 
            // linkLabelMortgage
            // 
            this.linkLabelMortgage.AutoSize = true;
            this.linkLabelMortgage.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linkLabelMortgage.LinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.linkLabelMortgage.Location = new System.Drawing.Point(56, 87);
            this.linkLabelMortgage.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.linkLabelMortgage.Name = "linkLabelMortgage";
            this.linkLabelMortgage.Size = new System.Drawing.Size(179, 20);
            this.linkLabelMortgage.TabIndex = 1;
            this.linkLabelMortgage.TabStop = true;
            this.linkLabelMortgage.Text = "Mortgage Calculator";
            this.linkLabelMortgage.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabelMortgage_LinkClicked);
            this.linkLabelMortgage.Click += new System.EventHandler(this.linkLabelMortgage_Click);
            // 
            // linkLabelIntrest
            // 
            this.linkLabelIntrest.AutoSize = true;
            this.linkLabelIntrest.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linkLabelIntrest.LinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.linkLabelIntrest.Location = new System.Drawing.Point(291, 143);
            this.linkLabelIntrest.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.linkLabelIntrest.Name = "linkLabelIntrest";
            this.linkLabelIntrest.Size = new System.Drawing.Size(165, 20);
            this.linkLabelIntrest.TabIndex = 2;
            this.linkLabelIntrest.TabStop = true;
            this.linkLabelIntrest.Text = "Interest Calculator";
            this.linkLabelIntrest.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabelIntrest_LinkClicked);
            this.linkLabelIntrest.Click += new System.EventHandler(this.linkLabelIntrest_Click);
            // 
            // linkLabelLoan
            // 
            this.linkLabelLoan.AutoSize = true;
            this.linkLabelLoan.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linkLabelLoan.LinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.linkLabelLoan.Location = new System.Drawing.Point(291, 87);
            this.linkLabelLoan.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.linkLabelLoan.Name = "linkLabelLoan";
            this.linkLabelLoan.Size = new System.Drawing.Size(142, 20);
            this.linkLabelLoan.TabIndex = 3;
            this.linkLabelLoan.TabStop = true;
            this.linkLabelLoan.Text = "Loan Calculator";
            this.linkLabelLoan.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabelLoan_LinkClicked);
            this.linkLabelLoan.Click += new System.EventHandler(this.linkLabelLoan_Click);
            // 
            // linkLabelIntrestRate
            // 
            this.linkLabelIntrestRate.AutoSize = true;
            this.linkLabelIntrestRate.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linkLabelIntrestRate.LinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.linkLabelIntrestRate.Location = new System.Drawing.Point(291, 199);
            this.linkLabelIntrestRate.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.linkLabelIntrestRate.Name = "linkLabelIntrestRate";
            this.linkLabelIntrestRate.Size = new System.Drawing.Size(210, 20);
            this.linkLabelIntrestRate.TabIndex = 4;
            this.linkLabelIntrestRate.TabStop = true;
            this.linkLabelIntrestRate.Text = "Interest Rate Calculator";
            this.linkLabelIntrestRate.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabelIntrestRate_LinkClicked);
            this.linkLabelIntrestRate.Click += new System.EventHandler(this.linkLabelIntrestRate_Click);
            // 
            // linkLabelIncomeTax
            // 
            this.linkLabelIncomeTax.AutoSize = true;
            this.linkLabelIncomeTax.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linkLabelIncomeTax.LinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.linkLabelIncomeTax.Location = new System.Drawing.Point(56, 143);
            this.linkLabelIncomeTax.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.linkLabelIncomeTax.Name = "linkLabelIncomeTax";
            this.linkLabelIncomeTax.Size = new System.Drawing.Size(197, 20);
            this.linkLabelIncomeTax.TabIndex = 6;
            this.linkLabelIncomeTax.TabStop = true;
            this.linkLabelIncomeTax.Text = "Income Tax Calculator";
            this.linkLabelIncomeTax.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabelIncomeTax_LinkClicked);
            this.linkLabelIncomeTax.Click += new System.EventHandler(this.linkLabelIncomeTax_Click);
            // 
            // linkLabelPayment
            // 
            this.linkLabelPayment.AutoSize = true;
            this.linkLabelPayment.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linkLabelPayment.LinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.linkLabelPayment.Location = new System.Drawing.Point(56, 199);
            this.linkLabelPayment.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.linkLabelPayment.Name = "linkLabelPayment";
            this.linkLabelPayment.Size = new System.Drawing.Size(173, 20);
            this.linkLabelPayment.TabIndex = 9;
            this.linkLabelPayment.TabStop = true;
            this.linkLabelPayment.Text = "Payment Calculator";
            this.linkLabelPayment.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabelPayment_LinkClicked);
            this.linkLabelPayment.Click += new System.EventHandler(this.linkLabelPayment_Click);
            // 
            // main_form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.RosyBrown;
            this.ClientSize = new System.Drawing.Size(526, 273);
            this.Controls.Add(this.linkLabelPayment);
            this.Controls.Add(this.linkLabelIncomeTax);
            this.Controls.Add(this.linkLabelIntrestRate);
            this.Controls.Add(this.linkLabelLoan);
            this.Controls.Add(this.linkLabelIntrest);
            this.Controls.Add(this.linkLabelMortgage);
            this.Controls.Add(this.label1);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "main_form";
            this.Text = "Financial Calculator";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.LinkLabel linkLabelMortgage;
        private System.Windows.Forms.LinkLabel linkLabelIntrest;
        private System.Windows.Forms.LinkLabel linkLabelLoan;
        private System.Windows.Forms.LinkLabel linkLabelIntrestRate;
        private System.Windows.Forms.LinkLabel linkLabelIncomeTax;
        private System.Windows.Forms.LinkLabel linkLabelPayment;
    }
}

