﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Case_Study
{
    public partial class main_form : Form
    {
        public main_form()
        {
            InitializeComponent();
        }

        private void linkLabelMortgage_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Mortgage_calculator m = new Mortgage_calculator();
            m.Show();
            this.Hide();
        }

        private void linkLabelMortgage_Click(object sender, EventArgs e)
        {
            Mortgage_calculator m = new Mortgage_calculator();
            m.ShowDialog();
        }
        private void linkLabelPayment_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Payment_calculator p=new Payment_calculator();
            p.Show();
            this.Hide();
        }

        private void linkLabelPayment_Click(object sender, EventArgs e)
        {
            Payment_calculator p = new Payment_calculator();
            p.ShowDialog();
        }

        private void linkLabelIncomeTax_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Income_tax_calculator i=new Income_tax_calculator();
            i.ShowDialog();
        }

        private void linkLabelIncomeTax_Click(object sender, EventArgs e)
        {
            Income_tax_calculator i = new Income_tax_calculator();
            i.Show();
            this.Hide();
        }

        private void linkLabelIntrestRate_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Income_tax_calculator i = new Income_tax_calculator();
            i.ShowDialog();
        }

        private void linkLabelIntrestRate_Click(object sender, EventArgs e)
        {
            Income_tax_calculator i = new Income_tax_calculator();
            i.Show();
            this.Hide();
        }

        private void linkLabelLoan_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Loan_calculator l=new Loan_calculator();
            l.ShowDialog();
        }

        private void linkLabelLoan_Click(object sender, EventArgs e)
        {
            Loan_calculator l=new Loan_calculator();
            l.Show();
            this.Hide();
        }

        private void linkLabelIntrest_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Interest_calculator i=new Interest_calculator();
            i.ShowDialog();
        }

        private void linkLabelIntrest_Click(object sender, EventArgs e)
        {
            Interest_calculator i= new Interest_calculator();
            i.Show();
            this.Hide();
        }

        
    }
}
