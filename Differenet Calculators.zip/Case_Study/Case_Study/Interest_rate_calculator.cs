﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Case_Study
{
    public partial class Interest_rate_calculator : Form
    {
        public Interest_rate_calculator()
        {
            InitializeComponent();
        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {
            try
            {
                // Retrieve input values
                double loanAmount = Convert.ToDouble(txtloanamount.Text);
                double monthlyPayment = Convert.ToDouble(txtloantermmonth.Text);

                // Retrieve loan term in years and months
                int loanTermYears = Convert.ToInt32(txtloantermYear.Text);
                int loanTermMonths = Convert.ToInt32(txtloantermmonth.Text);
                int totalLoanTermMonths = (loanTermYears * 12) + loanTermMonths;

                // Calculate the interest rate using the formula for loan payment
                double monthlyInterestRate = CalculateInterestRate(loanAmount, monthlyPayment, totalLoanTermMonths);
                double annualInterestRate = monthlyInterestRate * 12 * 100; // Convert to annual percentage

                // Display the result
                MessageBox.Show($"Interest Rate: {annualInterestRate:F2}%", "Calculated Interest Rate");

            }
            catch (FormatException)
            {
                MessageBox.Show("Please enter valid numeric values.");
            }
        }

        private double CalculateInterestRate(double loanAmount, double monthlyPayment, int totalLoanTermMonths)
        {
            // Using a simple iterative method to approximate the interest rate
            double lowRate = 0.0;
            double highRate = 1.0; // Start with a high rate
            double midRate;
            double epsilon = 0.01; // Allowable error

            while (highRate - lowRate > epsilon)
            {
                midRate = (lowRate + highRate) / 2;
                double calculatedPayment = (loanAmount * midRate / 12) /
                                            (1 - Math.Pow(1 + midRate / 12, -totalLoanTermMonths));

                if (calculatedPayment > monthlyPayment)
                {
                    highRate = midRate; // Reduce the high end
                }
                else
                {
                    lowRate = midRate; // Increase the low end
                }
            }

            return (lowRate + highRate) / 2; // Return the average as the estimated interest rate
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            // Clear all text boxes and result label
            txtloanamount.Clear();
            txtloantermYear.Clear();
            txtloantermmonth.Clear();
            txtmontypayment.Clear();
        }
    }
}
    

