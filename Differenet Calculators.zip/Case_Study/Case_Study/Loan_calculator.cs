﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Case_Study
{
    public partial class Loan_calculator : Form
    {
        public Loan_calculator()
        {
            InitializeComponent();
        }

        private void txtCalculate_Click(object sender, EventArgs e)
        {
            try
            {
                // Get values from input fields
                double loanAmount = double.Parse(txtLoanAmount.Text);
                int loanTermYears = int.Parse(txtloantermYear.Text);
                int loanTermMonths = int.Parse(txtloantermmonth.Text);
                double interestRate = double.Parse(txtInterestrate.Text);

                // Convert total loan term into months
                int totalMonths = (loanTermYears * 12) + loanTermMonths;

                // Convert annual interest rate into a monthly rate
                double monthlyRate = interestRate / 12 / 100;

                // Calculate monthly payment using the formula for EMI
                double monthlyPayment = (loanAmount * monthlyRate) /
                                         (1 - Math.Pow(1 + monthlyRate, -totalMonths));

                // Show the result in a message box or label
                MessageBox.Show($"Monthly Payment: {monthlyPayment:C}", "Calculation Result");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            // Clear the input fields
            txtLoanAmount.Clear();
            txtloantermYear.Clear();
            txtloantermmonth.Clear();
            txtInterestrate.Clear();
        }
    }
}
