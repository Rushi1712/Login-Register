﻿using System;
using System.Windows.Forms;

namespace Case_Study
{
    public partial class Income_tax_calculator : Form
    {
        public Income_tax_calculator()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {
            try
            {
                // Ensure a tax slab is selected
                if (cmbTaxSlab.SelectedIndex == -1)
                {
                    MessageBox.Show("Please select a tax slab.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                // Get input values
                double annualIncome = double.Parse(txtAnnualIncome.Text);
                double allowance = string.IsNullOrEmpty(txtTexFreeAllowance.Text) ? 0 : double.Parse(txtTexFreeAllowance.Text);

                // Get the selected tax slab
                string selectedSlab = cmbTaxSlab.SelectedItem.ToString();

                // Calculate taxable income
                double taxableIncome = annualIncome - allowance;

                // Calculate tax based on the selected slab
                double taxRate = GetTaxRate(selectedSlab);
                double calculatedTax = taxableIncome * taxRate;

                // Display the calculated tax in a message box
                MessageBox.Show("The calculated tax is: " + calculatedTax.ToString("C"),
                                "Tax Calculation",
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Information);
            }
            catch (FormatException)
            {
                MessageBox.Show("Please enter valid numbers for annual income and tax-free allowance.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message, "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Method to get the tax rate based on selected slab
        private double GetTaxRate(string slab)
        {
            switch (slab)
            {
                case "10%": return 0.10;
                case "20%": return 0.20;
                case "30%": return 0.30;
                default: throw new Exception("Invalid tax slab selected.");
            }
        }

        // Clear button event handler
        private void button1_Click(object sender, EventArgs e)
        {
            // Clear all input fields
            txtAnnualIncome.Clear();
            txtTexFreeAllowance.Clear();
            cmbTaxSlab.SelectedIndex = -1; // Reset the tax slab selection
        }
    }
}
