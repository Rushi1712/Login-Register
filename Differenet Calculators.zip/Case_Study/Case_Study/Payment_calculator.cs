﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Case_Study
{
    public partial class Payment_calculator : Form
    {
        public Payment_calculator()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

       

        private void btnCalculate_Click(object sender, EventArgs e)
        {
            double loanAmount = Convert.ToDouble(txtloanamount.Text);
            double annualInterestRate = Convert.ToDouble(txtInterestrate.Text) / 100;
            int loanTerm = Convert.ToInt32(txtloanterm.Text);

            // Calculate monthly payment
            double monthlyInterestRate = annualInterestRate / 12;
            int numberOfPayments = loanTerm * 12;
            double monthlyPayment = (loanAmount * monthlyInterestRate) /
                                    (1 - Math.Pow(1 + monthlyInterestRate, -numberOfPayments));

            // Display the result
            MessageBox.Show($"Monthly Payment: {monthlyPayment:C}");
        }

        private void btnclear_Click_1(object sender, EventArgs e)
        {
            // Clear all text boxes
            txtloanamount.Clear();
            txtloanterm.Clear();
            txtInterestrate.Clear();
        }
    }
}
