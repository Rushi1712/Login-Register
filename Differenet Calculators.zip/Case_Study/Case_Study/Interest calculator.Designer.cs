﻿namespace Case_Study
{
    partial class Interest_calculator
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtinvestment = new System.Windows.Forms.TextBox();
            this.txtrate = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtcontributer = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtannual = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.txtinflationrate = new System.Windows.Forms.TextBox();
            this.txttaxrate = new System.Windows.Forms.TextBox();
            this.txtmonth = new System.Windows.Forms.TextBox();
            this.txtyear = new System.Windows.Forms.TextBox();
            this.cmbcomponend = new System.Windows.Forms.ComboBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.btncalculate = new System.Windows.Forms.Button();
            this.btnclear = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(144, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(174, 24);
            this.label1.TabIndex = 0;
            this.label1.Text = "Interest calculator";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(66, 69);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(135, 17);
            this.label2.TabIndex = 1;
            this.label2.Text = "Initial investment:\t";
            // 
            // txtinvestment
            // 
            this.txtinvestment.Location = new System.Drawing.Point(223, 64);
            this.txtinvestment.Name = "txtinvestment";
            this.txtinvestment.Size = new System.Drawing.Size(145, 22);
            this.txtinvestment.TabIndex = 2;
            // 
            // txtrate
            // 
            this.txtrate.Location = new System.Drawing.Point(223, 170);
            this.txtrate.Name = "txtrate";
            this.txtrate.Size = new System.Drawing.Size(145, 22);
            this.txtrate.TabIndex = 4;
            this.txtrate.Text = "x";
            this.txtrate.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(99, 173);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(102, 17);
            this.label3.TabIndex = 3;
            this.label3.Text = "Interest rate:";
            // 
            // txtcontributer
            // 
            this.txtcontributer.Location = new System.Drawing.Point(223, 133);
            this.txtcontributer.Name = "txtcontributer";
            this.txtcontributer.Size = new System.Drawing.Size(145, 22);
            this.txtcontributer.TabIndex = 6;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(47, 138);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(160, 17);
            this.label4.TabIndex = 5;
            this.label4.Text = "Monthly contribution:";
            // 
            // txtannual
            // 
            this.txtannual.Location = new System.Drawing.Point(223, 98);
            this.txtannual.Name = "txtannual";
            this.txtannual.Size = new System.Drawing.Size(145, 22);
            this.txtannual.TabIndex = 8;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(47, 101);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(154, 17);
            this.label5.TabIndex = 7;
            this.label5.Text = "Annual contribution:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(128, 261);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(73, 17);
            this.label6.TabIndex = 9;
            this.label6.Text = "Tax rate:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(60, 233);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(141, 17);
            this.label7.TabIndex = 10;
            this.label7.Text = "Investment length:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(112, 202);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(89, 17);
            this.label8.TabIndex = 11;
            this.label8.Text = "Compound:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(96, 294);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(105, 17);
            this.label9.TabIndex = 12;
            this.label9.Text = "Inflation rate:";
            // 
            // txtinflationrate
            // 
            this.txtinflationrate.Location = new System.Drawing.Point(220, 289);
            this.txtinflationrate.Name = "txtinflationrate";
            this.txtinflationrate.Size = new System.Drawing.Size(148, 22);
            this.txtinflationrate.TabIndex = 13;
            this.txtinflationrate.Text = "%";
            this.txtinflationrate.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txttaxrate
            // 
            this.txttaxrate.Location = new System.Drawing.Point(220, 256);
            this.txttaxrate.Name = "txttaxrate";
            this.txttaxrate.Size = new System.Drawing.Size(148, 22);
            this.txttaxrate.TabIndex = 14;
            this.txttaxrate.Text = "%";
            this.txttaxrate.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtmonth
            // 
            this.txtmonth.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtmonth.Location = new System.Drawing.Point(294, 230);
            this.txtmonth.MaximumSize = new System.Drawing.Size(100, 1);
            this.txtmonth.MinimumSize = new System.Drawing.Size(0, 1);
            this.txtmonth.Name = "txtmonth";
            this.txtmonth.Size = new System.Drawing.Size(77, 19);
            this.txtmonth.TabIndex = 15;
            this.txtmonth.Text = "Months";
            this.txtmonth.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtyear
            // 
            this.txtyear.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtyear.Location = new System.Drawing.Point(207, 230);
            this.txtyear.MaximumSize = new System.Drawing.Size(100, 1);
            this.txtyear.MinimumSize = new System.Drawing.Size(0, 1);
            this.txtyear.Name = "txtyear";
            this.txtyear.Size = new System.Drawing.Size(77, 19);
            this.txtyear.TabIndex = 16;
            this.txtyear.Text = "Years";
            this.txtyear.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//            this.txtyear.TextChanged += new System.EventHandler(this.txtyear_TextChanged);
            // 
            // cmbcomponend
            // 
            this.cmbcomponend.FormattingEnabled = true;
            this.cmbcomponend.Items.AddRange(new object[] {
            "Annually",
            "Quarterly",
            "Monthly"});
            this.cmbcomponend.Location = new System.Drawing.Point(223, 198);
            this.cmbcomponend.Name = "cmbcomponend";
            this.cmbcomponend.Size = new System.Drawing.Size(145, 24);
            this.cmbcomponend.TabIndex = 17;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(284, 239);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(0, 13);
            this.label10.TabIndex = 18;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(377, 239);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(0, 13);
            this.label11.TabIndex = 19;
            // 
            // btncalculate
            // 
            this.btncalculate.BackColor = System.Drawing.Color.ForestGreen;
            this.btncalculate.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btncalculate.Location = new System.Drawing.Point(84, 340);
            this.btncalculate.Name = "btncalculate";
            this.btncalculate.Size = new System.Drawing.Size(93, 37);
            this.btncalculate.TabIndex = 20;
            this.btncalculate.Text = "Calculate";
            this.btncalculate.UseVisualStyleBackColor = false;
            this.btncalculate.Click += new System.EventHandler(this.btncalculate_Click);
            // 
            // btnclear
            // 
            this.btnclear.BackColor = System.Drawing.SystemColors.Control;
            this.btnclear.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnclear.Location = new System.Drawing.Point(211, 340);
            this.btnclear.Name = "btnclear";
            this.btnclear.Size = new System.Drawing.Size(93, 37);
            this.btnclear.TabIndex = 21;
            this.btnclear.Text = "Clear";
            this.btnclear.UseVisualStyleBackColor = false;
            // 
            // Interest_calculator
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(452, 402);
            this.Controls.Add(this.btnclear);
            this.Controls.Add(this.btncalculate);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.cmbcomponend);
            this.Controls.Add(this.txtyear);
            this.Controls.Add(this.txtmonth);
            this.Controls.Add(this.txttaxrate);
            this.Controls.Add(this.txtinflationrate);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.txtannual);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.txtcontributer);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txtrate);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtinvestment);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Interest_calculator";
            this.Text = "Interest_calculator";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtinvestment;
        private System.Windows.Forms.TextBox txtrate;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtcontributer;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtannual;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtinflationrate;
        private System.Windows.Forms.TextBox txttaxrate;
        private System.Windows.Forms.TextBox txtmonth;
        private System.Windows.Forms.TextBox txtyear;
        private System.Windows.Forms.ComboBox cmbcomponend;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Button btncalculate;
        private System.Windows.Forms.Button btnclear;
    }
}