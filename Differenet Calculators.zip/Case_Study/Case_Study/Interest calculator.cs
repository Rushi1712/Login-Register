﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Case_Study
{
    public partial class Interest_calculator : Form
    {
        public Interest_calculator()
        {
            InitializeComponent();
        }

        private void btncalculate_Click(object sender, EventArgs e)
        {
            try
            {
                // Reading inputs with validation
                if (!double.TryParse(txtinvestment.Text, out double initialInvestment) ||
                    !double.TryParse(txtcontributer.Text, out double annualContribution) ||
                    !double.TryParse(txtmonth.Text, out double monthlyContribution) ||
                    !double.TryParse(txtrate.Text, out double interestRate) ||
                    !double.TryParse(txttaxrate.Text, out double taxRate) ||
                    !double.TryParse(txtinflationrate.Text, out double inflationRate))
                {
                    MessageBox.Show("Error: Please ensure all inputs are valid numeric values.");
                    return;
                }

                interestRate /= 100;
                taxRate /= 100;
                inflationRate /= 100;
                int investmentYears = Convert.ToInt32(txtyear.Text);
                int investmentMonths = Convert.ToInt32(txtmonth.Text);
                double totalYears = investmentYears + (investmentMonths / 12.0);

                // Getting compound frequency
                int compoundPerYear = 1;
                if (cmbcomponend.SelectedItem != null)
                {
                    switch (cmbcomponend.SelectedItem.ToString())
                    {
                        case "Annually":
                            compoundPerYear = 1;
                            break;
                        case "Quarterly":
                            compoundPerYear = 4;
                            break;
                        case "Monthly":
                            compoundPerYear = 12;
                            break;
                        default:
                            MessageBox.Show("Error: Please select a valid compounding frequency.");
                            return;
                    }
                }

                // Future value calculation
                double futureValue = initialInvestment * Math.Pow((1 + interestRate / compoundPerYear), compoundPerYear * totalYears);

                // Adding contributions (Annual + Monthly)
                for (int i = 1; i <= investmentYears; i++)
                {
                    futureValue += annualContribution * Math.Pow((1 + interestRate / compoundPerYear), compoundPerYear * (investmentYears - i));
                }

                // Adding monthly contributions
                for (int i = 1; i <= totalYears * 12; i++)
                {
                    futureValue += monthlyContribution * Math.Pow((1 + interestRate / compoundPerYear), compoundPerYear * totalYears - (i / 12.0));
                }

                // Adjusting for tax and inflation
                double taxDeductedValue = futureValue * (1 - taxRate);
                double inflationAdjustedValue = taxDeductedValue / Math.Pow(1 + inflationRate, totalYears);

                // Showing the result in a message box
                MessageBox.Show($"Future Value: {futureValue:C}\n" +
                                $"After Tax: {taxDeductedValue:C}\n" +
                                $"After Inflation Adjustment: {inflationAdjustedValue:C}",
                                "Calculation Result");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        
    }
}
